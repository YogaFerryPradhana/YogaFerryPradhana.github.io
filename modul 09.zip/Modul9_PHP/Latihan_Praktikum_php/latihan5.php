<!DOCTYPE html>
<html>
<head>
	<title>Latihan 5 pemrograman web</title>
</head>
<body>
	<?php
		$nim = "15211001" ; // sesuaikan dengan nim anda
		$nama = "aldi setiadi"; //sesuaikan dengan nama anda
		$angka1 = 10;
		$angka2 = 15;

		$hasilpenjumlahan = $angka1 + $angka2;

		echo "NIM : ". $nim . "<br/>";
		echo "NAMA : ". $nama . "<br/>";
		echo "Hasil Penjualan dari ". $angka1 ." dan ". $angka2. " = " . $hasilpenjumlahan. "<br/>";
	?>
</body>
</html>