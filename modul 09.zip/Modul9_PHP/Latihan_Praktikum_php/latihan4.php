<!DOCTYPE html>
<html>
<head>
	<title>Latihan 4 Pemrograman web</title>
</head>
<body>
	<?php
  		$bilanganbulat = 17; // nilai variabel yang berisi angka (integer)
  		$teks = "aku"; // nilai variabel yang berisi kata (string)
  		$bilangandesimal = 17.42; // nilai variabel yang berisi angka desimal (float)

  		echo "Nilai Variabel bilanganbulat: " . $bilanganbulat . "<br/>";
  		echo "Nilai Variabel teks: " . $teks . "<br/>";
  		echo "Nilai Variabel bilangandesimal: " . $bilangandesimal . "<br/>";
?>

</body>
</html>