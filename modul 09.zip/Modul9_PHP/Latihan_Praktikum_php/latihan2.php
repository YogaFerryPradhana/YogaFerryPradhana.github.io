<?php
	for ($i =1; $i <=10; $i++) {
		echo "kata ini dicetak sebanyak 10 kali <br>";
	}
?>