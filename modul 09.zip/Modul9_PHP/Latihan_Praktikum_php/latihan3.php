<!DOCTYPE html>
<html>
<head>
	<title>Latihan 3 Pemrograman web</title>
</head>
<body>
	<font color="red">
		<?php echo "Tulisan ini berwarna merah"; ?>
	</font>

	<?php 
		echo "<br/><b>Tulisan dalam bold atau tulisan tebal</b>";
	?>
</body>
</html>